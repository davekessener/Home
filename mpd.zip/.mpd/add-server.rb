require 'fileutils'

class MPDConfig
	def initialize(data)
		lines = data.split(/\n/).tap { |a| a.each { |l| l.gsub!(/[\t ]+/, ' '); l.strip! } }
		lines.reject! { |l| l.length == 0 or l[0] == '#' }
		@data = {}
		generate(lines, @data)
	end

	def set(id, v)
		t, id = *get_by_id(id)
		t[id] = v
	end

	def get(id)
		t, id = *get_by_id(id)
		t[id]
	end

	def remove(id)
		t, id = *get_by_id(id)
		t.delete id
	end

	def stringify
		to_string(@data, [], '').join("\n")
	end

	private

	def get_by_id(id)
		ids = id.split(/:/).map { |e| e.to_sym }
		t = @data
		t = t[ids.shift] while ids.length > 1
		[t, ids.shift]
	end

	def to_string(d, a, o)
		d.each do |id, v|
			unless v.is_a? Hash
				a << "#{o}#{id} \"#{v.to_s}\""
			else
				a << "#{o}#{id} {"
				to_string(v, a, "    #{o}")
				a << "#{o}}"
			end
		end
		a
	end

	def generate(ls, h)
		until ls.empty?
			l = ls.shift

			break if l == '}'
			
			id, arg = *l.split(/ +/, 2)
			
			id = id.to_sym
			
			if arg.nil?
				raise l
			elsif arg.end_with? '{'
				generate(ls, h[id] = {})
			elsif arg =~ /^"([^"]+)"/
				h[id] = $1
			else
				raise l
			end
		end
	end
end

Dir.chdir "/home/osmc/.mpd" do
	idx = 1 + Dir.glob('server-*').length
	dir = "server-#{idx}"
	Dir.mkdir dir
	template = File.read('mpd.conf')
	begin
		Dir.chdir dir do
			config = MPDConfig.new(template)
			
			['log', 'pid', 'state'].each do |id|
				FileUtils.touch(id)
				config.set("#{id}_file", "~/.mpd/#{dir}/#{id}")
			end
			
			ctrl_port = config.get('port').to_i + idx
			http_port = config.get('audio_output:port').to_i + idx

			config.set('port', ctrl_port)
			config.set('audio_output:port', http_port)
			config.set('audio_output:name', dir)
			config.set('database', {
				plugin: 'proxy',
				host: 'localhost',
				port: '6600'
			})

			File.open('mpd.conf', 'w') do |f|
				f.write(config.stringify)
			end
		end

		puts "Successfully generated configuration for #{dir}!"
	rescue
		puts "Some error occured"
		FileUtils.rm_rf(dir)
		raise
	end
end

